from PyQt5 import QtCore, QtGui, QtWidgets
from BL_login import BL_login
from feedbackRating import Ui_feedbackRating

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(222, 219)
        font = QtGui.QFont()
        font.setPointSize(10)
        Dialog.setFont(font)
        self.lineEdit = QtWidgets.QLineEdit(Dialog)
        self.lineEdit.setGeometry(QtCore.QRect(30, 20, 161, 41))
        self.lineEdit.setObjectName("lineEdit")
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(70, 70, 121, 41))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(40, 140, 141, 51))
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton.setFont(font)
        self.pushButton.setObjectName("pushButton")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
        
        self.pushButton.clicked.connect(self.login)
        self.pushButton.clicked.connect(self.pushButton_clicked)
        
    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Login"))
        self.label.setText(_translate("Dialog", "Username"))
        self.pushButton.setText(_translate("Dialog", "Enter"))
        
    def success(self,text,title):
        nice = QtWidgets.QMessageBox()
        nice.setIcon(QtWidgets.QMessageBox.Information)
        nice.setText(text)
        nice.setWindowTitle(title)
        nice.setStandardButtons(QtWidgets.QMessageBox.Ok)
        nice.exec_()
        
    def pushButton_clicked(self):      
        self.feedbackRating = QtWidgets.QDialog()
        self.fbr = Ui_feedbackRating()
        self.fbr.setupUi(self.feedbackRating)
        self.feedbackRating.show()
        Dialog.close()
        
    def login(self):
        logic = BL_login()
        uname = (self.lineEdit.text())            
        if logic.check_user(uname) == True:
            self.success("Username is Found!","Success!")
        else:
            logic.add_user(uname)
            self.success("Username is Added!","Success!")
            
if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

