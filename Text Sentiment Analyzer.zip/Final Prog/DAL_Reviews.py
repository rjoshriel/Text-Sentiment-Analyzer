import sqlite3
class DAL_rev(object):
    
    def sorting(self):
        conn = sqlite3.connect('products.db')
        que = "SELECT * FROM Reviews ORDER BY rating desc"
        res = conn.execute(que)
        return res
        
    def goodReview(self):
        conn = sqlite3.connect('products.db')
        que = "SELECT * FROM Reviews WHERE rating >= 3 ORDER BY rating desc"
        res = conn.execute(que)
        return res
    
    def badReview(self):
        conn = sqlite3.connect('products.db')
        que = "SELECT * FROM Reviews WHERE rating < 3 ORDER BY rating desc"
        res = conn.execute(que)
        return res