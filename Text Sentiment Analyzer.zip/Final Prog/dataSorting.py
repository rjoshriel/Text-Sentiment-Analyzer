from PyQt5 import QtCore, QtGui, QtWidgets
from Reviews import Ui_viewRecords

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(396, 176)
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(220, 140, 75, 23))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(310, 140, 75, 23))
        self.pushButton_2.setObjectName("pushButton_2")
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(30, 0, 341, 151))
        self.label.setObjectName("label")
        
        #Button Signal
        self.pushButton.clicked.connect(self.viewRec_clicked)
        self.pushButton_2.clicked.connect(self.exitButton_clicked)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Sorting"))
        self.pushButton.setText(_translate("Dialog", "Proceed"))
        self.pushButton_2.setText(_translate("Dialog", "Exit"))
        self.label.setText(_translate("Dialog", "<html><head/><body><p align=\"center\"><span style=\" font-size:11pt; font-weight:600;\">Awesome!</span></p><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">Thank you for rating our product. We\'ll make sure to </span></p><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">read your feedback.</span></p><p><span style=\" font-size:9pt;\">Data is now being sorted.</span></p><p><span style=\" font-size:9pt;\">Please wait..</span></p></body></html>"))
        
    #View Rec Button    
    def viewRec_clicked(self):
        self.viewRecords = QtWidgets.QDialog()
        self.vr = Ui_viewRecords()
        self.vr.setupUi(self.viewRecords)
        self.viewRecords.show()
        Dialog.close()
        
    def exitButton_clicked(self):
        Dialog.close()
    
if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())