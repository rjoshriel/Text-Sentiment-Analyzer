from DAL_Login import DAL_login

class BL_login(object):
    def check_user(self, uLine):
        found = False
        DA_user = DAL_login()
        user = DA_user.check_user(uLine)
        if user is None:
            return found
        else:
            found = True
            return found
    def add_user(self,uLine):
        DA_user = DAL_login()
        user = DA_user.check_user(uLine)
        if user is None:
            DA_user.add_user(uLine)
        else:
            print("There must be an Error!")