# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 21:02:03 2019

@author: ELVIN
"""

import sqlite3

class DAL_login(object):
    
    def add_user(self,user):
        conn = sqlite3.connect('products.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO Reviews (Name) VALUES('%s')" %user)
        conn.commit() 
        conn.close()
        
    def check_user(self,user):
        conn = sqlite3.connect('products.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Reviews Where Name=?",[(user)])
        return cursor.fetchone()